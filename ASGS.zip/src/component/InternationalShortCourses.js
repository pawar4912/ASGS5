import React from "react";

function InternationalShortCourses() {
  return (
    <div>
      <h3 className="heading-text heading-gap">International Short Courses </h3>
    </div>
  );
}
export default InternationalShortCourses;