import React from 'react'

 function Policy() {
  return (
    <div>
<h2 className='text-center'>Privacy Policy</h2>
    </div>
  )
}
export default Policy