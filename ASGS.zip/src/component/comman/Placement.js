import React from 'react'

 function Placement() {
  return (
    <div>
<h2 className='text-center'>Placement</h2>
    </div>
  )
}
export default Placement