import React from "react";

function Sucess() {
  return (
    <div>
      <h3 className="heading-text heading-gap">Success Stories</h3>
    </div>
  );
}

export default Sucess;
