
import React from 'react'

export default function Contact() {
  return (
    <div>
    <h2 className='text-center'>Contact  Us</h2>
  </div>
  )
}
