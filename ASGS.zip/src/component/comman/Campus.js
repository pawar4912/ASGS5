import React from 'react'

 function Campus() {
  return (
    <div>
<h2 className='text-center'>Campus Life</h2>
    </div>
  )
}
export default Campus