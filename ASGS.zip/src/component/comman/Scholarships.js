import React from 'react'

 function Scholarships() {
  return (
    <div>
      <h3 className="heading-text heading-gap">Scholarships</h3>
    </div>
  )
}

export default Scholarships