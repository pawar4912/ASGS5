import React from "react";

function Study() {
  return (
    <div>
      <h3 className="heading-text heading-gap">Study Center</h3>
    </div>
  );
}
export default Study;
