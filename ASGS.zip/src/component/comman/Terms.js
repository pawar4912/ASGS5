import React from 'react'

 function Terms() {
  return (
    <div>
      <h2 className='text-center'>Terms And Condition</h2>
    </div>
  )
}
export default Terms