import React from "react";
function InternationalBachelors() {
  return (
    <div>
      <h3 className="heading-text heading-gap">International Bachelors </h3>
    </div>
  );
}
export default InternationalBachelors;
