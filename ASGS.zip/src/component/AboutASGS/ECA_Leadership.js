import React from "react";

function ECA_Leadership() {
  return (
    <div className="background-even">
      <div className=" row text-center">
        <h3 className="section-heading ">ASGS Leadership Team</h3>
      </div>
      <div className="margin_top">
        <div className="row">
          <div className="back_color1">
            <div className="leader-card">
              <div className="d-flex bg_colored ">
                <div>
                  <h4 className="mt-4">Mr.Rupesh Singh</h4>
                  <span>CEO,ECA</span>
                  <p className="padding_P mt-3">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen book. It has survived not only five centuries,
                    but also the leap into electronic typesetting.
                  </p>
                </div>
                <div>
                  <img
                    className=""
                    src={require("../../asset/Rectangle 362.png")}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="row">
          <div className="back_color12">
            <div className="d-flex">
              <div className="col-lg-5"></div>
              <div className="leader-card ">
                <div className="d-flex bg_colored1 ">
                  <div>
                    <img
                      className=""
                      src={require("../../asset/Rectangle 362.png")}
                    />
                  </div>
                  <div>
                    <h4 className="mt-4 padding_Pl">Mr.Rajesh Singh</h4>
                    <span className="padding_Pl">CEO,ECA Global</span>
                    <p className="padding_Pl mt-3">
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum has been the industry's
                      standard dummy text ever since the 1500s, when an unknown
                      printer took a galley of type and scrambled it to make a
                      type specimen book. It has survived not only five
                      centuries, but also the leap into electronic typesetting.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="row ">
          <div className="back_color1">
            <div className="leader-card">
              <div className="d-flex bg_colored ">
                <div>
                  <h4 className="mt-4">Mr.Lawrence Pratchett</h4>
                  <span>CEO,ASGS</span>
                  <p className="padding_P mt-3">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen book. It has survived not only five centuries,
                    but also the leap into electronic typesetting.
                  </p>
                </div>
                <div>
                  <img
                    className=""
                    src={require("../../asset/Rectangle 362.png")}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="row">
          <div className="back_color12">
            <div className="d-flex">
              <div className="col-lg-5"></div>
              <div className="leader-card ">
                <div className="d-flex bg_colored1 ">
                  <div>
                    <img
                      className=""
                      src={require("../../asset/Rectangle 362.png")}
                    />
                  </div>
                  <div>
                    <h4 className="mt-4 padding_Pl">Mr.Scott Dickson</h4>
                    <span className="padding_Pl">
                      CEO,Academic Officer,ASGS
                    </span>
                    <p className="padding_Pl mt-3">
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum has been the industry's
                      standard dummy text ever since the 1500s, when an unknown
                      printer took a galley of type and scrambled it to make a
                      type specimen book. It has survived not only five
                      centuries, but also the leap into electronic typesetting.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="row ">
          <div className="back_color1">
            <div className="leader-card">
              <div className="d-flex bg_colored ">
                <div>
                  <h4 className="mt-4">Prof Bhawna Kumar </h4>
                  <span>Academic Director,ASGS</span>
                  <p className="padding_P mt-3">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen book. It has survived not only five centuries,
                    but also the leap into electronic typesetting.
                  </p>
                </div>
                <div>
                  <img
                    className=""
                    src={require("../../asset/Rectangle 362.png")}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="row">
          <div className="back_color12">
            <div className="d-flex">
              <div className="col-lg-5"></div>
              <div className="leader-card ">
                <div className="d-flex bg_colored1 ">
                  <div>
                    <img
                      className=""
                      src={require("../../asset/Rectangle 362.png")}
                    />
                  </div>
                  <div>
                    <h4 className="mt-4 padding_Pl">Prof.Manoj Kumar</h4>
                    <span className="padding_Pl">
                      Director - CRC,ECA Global
                    </span>
                    <p className="padding_Pl mt-3">
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum has been the industry's
                      standard dummy text ever since the 1500s, when an unknown
                      printer took a galley of type and scrambled it to make a
                      type specimen book. It has survived not only five
                      centuries, but also the leap into electronic typesetting.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ECA_Leadership;
