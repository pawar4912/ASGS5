import React from "react";

function ECA_Faculty() {
  return (
    <div className="background-odd padding_top">
      <div className=" row text-center">
        <h3 className="section-heading ">ASGS Faculty</h3>
      </div>
      <div className="row  team-section">
        <div className="bordss">
          <div className="abt_team">
            <div>
              <div className="img_shadow">
                <img
                  src={require("../../asset/logo/team/Rupesh-Singh.png")}
                  width={245}
                  height={279}
                  className="imgSlider1 img_shad"
                  alt="team-member-img"
                ></img>
              </div>
              <div className="text_back">
                <span className="mainname1">Andrew Halloway</span>

                <div className="submainname1">Vice-President,</div>
                <span className="submainname1">
                  University Partnerships Pathways
                </span>
              </div>
            </div>
            <div>
              <div className="img_shadow">
                <img
                  src={require("../../asset/logo/team/Rupesh-Singh.png")}
                  width={245}
                  height={279}
                  className="imgSlider1 img_shad"
                  alt="team-member-img"
                ></img>
              </div>
              <div className="text_back">
                <span className="mainname1">Andrew Halloway</span>

                <div className="submainname1">Vice-President,</div>
                <span className="submainname1">
                  University Partnerships Pathways
                </span>
              </div>
            </div>
            <div>
              <div className="img_shadow">
                <img
                  src={require("../../asset/logo/team/Rupesh-Singh.png")}
                  width={245}
                  height={279}
                  className="imgSlider1 img_shad"
                  alt="team-member-img"
                ></img>
              </div>
              <div className="text_back">
                <span className="mainname1">Andrew Halloway</span>

                <div className="submainname1">Vice-President,</div>
                <span className="submainname1">
                  University Partnerships Pathways
                </span>
              </div>
            </div>
          </div>
          <div className="abt_team">
            <div>
              <div className="img_shadow">
                <img
                  src={require("../../asset/logo/team/Rupesh-Singh.png")}
                  width={245}
                  height={279}
                  className="imgSlider1 img_shad"
                  alt="team-member-img"
                ></img>
              </div>
              <div className="text_back">
                <span className="mainname1">Andrew Halloway</span>

                <div className="submainname1">Vice-President,</div>
                <span className="submainname1">
                  University Partnerships Pathways
                </span>
              </div>
            </div>

            <div>
              <div className="img_shadow">
                <img
                  src={require("../../asset/logo/team/Rupesh-Singh.png")}
                  width={245}
                  height={279}
                  className="imgSlider1 img_shad"
                  alt="team-member-img"
                ></img>
              </div>
              <div className="text_back">
                <span className="mainname1">Andrew Halloway</span>

                <div className="submainname1">Vice-President,</div>
                <span className="submainname1">
                  University Partnerships Pathways
                </span>
              </div>
            </div>

            <div>
              <div className="img_shadow">
                <img
                  src={require("../../asset/logo/team/Rupesh-Singh.png")}
                  width={230}
                  height={279}
                  className="imgSlider1 img_shad"
                  alt="team-member-img"
                ></img>
              </div>
              <div className="text_back">
                <span className="mainname1">Andrew Halloway</span>

                <div className="submainname1">Vice-President,</div>
                <span className="submainname1">
                  University Partnerships Pathways
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ECA_Faculty;
