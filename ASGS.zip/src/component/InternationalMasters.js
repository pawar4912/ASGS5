import React from "react";

function InternationalMasters() {
  return (
    <div>
      <h3 className="heading-text heading-gap">International Masters </h3>
    </div>
  );
}
export default InternationalMasters;