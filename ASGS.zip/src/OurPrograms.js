import Carousels1 from "../src/component/about/Carousels1"
import Info from "./component/about/Info";
import TestimonialsA from "./component/about/testimonalsA";
import FooterA from "./component/about/FooterA";



function OurPrograms() {
   
    return (
      
      <div>
       <Carousels1></Carousels1>
       <Info></Info>
       <TestimonialsA></TestimonialsA>
     <FooterA></FooterA>
      
 
      </div>
      
    );
  }
  
  export default OurPrograms;